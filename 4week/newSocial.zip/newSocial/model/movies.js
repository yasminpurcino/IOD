class Movie {
    constructor(title, storyline, image, review) {
        //contructor definiu como constroi um objeto / instance
        //definindo os atributos usando os valores passados pelos argumentos 
        this.title = title
        this.storyline = storyline
        this.image = image
        this.review = review

    }


}


module.exports = Movie;  

